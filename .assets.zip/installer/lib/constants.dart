/*
 * This file is part of Aliucord, an Android Discord client mod.
 * Copyright (c) 2023 Juby210 & Vendicated
 * Licensed under the Open Software License version 3.0
 */

const backendHost = 'https://aliucord.com/';
const defaultDexLocation = '/storage/emulated/0/Aliucord/Injector.dex';
const supportServer = 'EsNDvBaHVU';
