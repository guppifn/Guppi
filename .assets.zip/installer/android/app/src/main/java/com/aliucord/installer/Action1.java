package com.aliucord.installer;

public interface Action1<T> {
    void call(T t);
}
