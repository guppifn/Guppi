# DiscordStubs

Stubs for Discord's classes.

This shouldn't be needed as we use [dex2jar](https://github.com/Aliucord/dex2jar) to generate a jar with Discords classes and use that
as stubs, but it incorrectly decompiles some nested classes, so those cases are manually fixed by these stubs.