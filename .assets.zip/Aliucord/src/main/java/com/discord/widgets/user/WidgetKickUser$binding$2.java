/*
 * This file is part of Aliucord, an Android Discord client mod.
 * Copyright (c) 2021 Juby210 & Vendicated
 * Licensed under the Open Software License version 3.0
 */

package com.discord.widgets.user;

import android.view.View;

import com.discord.databinding.WidgetKickUserBinding;

public class WidgetKickUser$binding$2 {
    public static WidgetKickUser$binding$2 INSTANCE;

    public final WidgetKickUserBinding invoke(View view) {
        throw new RuntimeException("Stub");
    }
}
