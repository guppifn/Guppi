/*
 * This file is part of Aliucord, an Android Discord client mod.
 * Copyright (c) 2021 Juby210 & Vendicated
 * Licensed under the Open Software License version 3.0
 */

package com.discord.widgets.chat.input;

public class WidgetChatInput$configureSendListeners$7$1 {
    public WidgetChatInput$configureSendListeners$7 this$0;
}
